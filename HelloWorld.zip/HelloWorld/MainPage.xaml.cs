﻿using System;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace HelloWorld
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        double gWidth;
        double gHeight;
        double gWoodLength;
        double gArea;
        double gQuantity;
        string gTint; 

        enum tintColor
        {
            black,
            brown,
            blue
        }

        public MainPage()
        {
            this.InitializeComponent();
            tint_black.IsChecked = true;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            MediaElement mediaElement = new MediaElement();
            var synth = new Windows.Media.SpeechSynthesis.SpeechSynthesizer();
            Windows.Media.SpeechSynthesis.SpeechSynthesisStream stream = await synth.SynthesizeTextToStreamAsync("Hello, World!");
            mediaElement.SetSource(stream, stream.ContentType);
            mediaElement.Play();
        }

        private void width_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                double enteredWidth = Convert.ToDouble(width.Text);

                if (enteredWidth < 0.5 || enteredWidth > 5.0)
                {
                    width_valid.Text = "Not Valid";
                }
                else
                {
                    width_valid.Text = "Valid";
                    gWidth = enteredWidth;
                }
            }
            catch (Exception)
            {
                width_valid.Text = "Not Valid";
            }
        }

        private void height_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                double enteredHeight = Convert.ToDouble(height.Text);

                if (enteredHeight < 0.75 || enteredHeight > 3.0)
                {
                    height_valid.Text = "Not Valid";
                }
                else
                {
                    height_valid.Text = "Valid";
                    gHeight = enteredHeight;
                }
            }
            catch (Exception)
            {
                height_valid.Text = "Not Valid";
            }
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void Slider_ValueChanged(object sender, Windows.UI.Xaml.Controls.Primitives.RangeBaseValueChangedEventArgs e)
        {
            sliderValue.Text = slider.Value.ToString();
            gQuantity = slider.Value;
        }

        private void calculate_Click(object sender, RoutedEventArgs e)
        {
            if(tint_black.IsChecked == true)
            {
                gTint = "Black";
            }
            else if (tint_blue.IsChecked == true)
            {
                gTint = "Blue";
            }
            else if (tint_brown.IsChecked == true)
            {
                gTint = "Brown";
            }
            gArea = (gWidth * gHeight) * 2;
            gWoodLength = gArea * 3.25;
            string date = DateTime.Now.ToString("dd-MM-yyyy");
            string result = $"Date = {date}\nWood Length = {gWoodLength} feet\nArea = {gArea} square meters\nTint = {gTint}\nQuantity = {gQuantity}\n";
            results.Text = result;


        }
    }
}
